import React from "react";
import { createTree } from "./Tree";
import roots from "./JSON/forceTree copy.json";
import root from "./JSON/forceTree.json";

class Tree extends React.Component {
    
    componentDidMount() {
        if (!this.treeElem) return;

        createTree(root, this.treeElem);
    }

    render() {
        console.log(root);
        console.log(roots.nodes);
        return (
            <div className="forceGraph" ref={(n) => { this.treeElem = n }}>
            </div>
        );
    }
}

export default Tree;